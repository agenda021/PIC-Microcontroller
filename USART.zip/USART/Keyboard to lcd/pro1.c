#include<pic.h>
#define backlight RB0
#define rs RB1
#define rw RB2
#define en RB3

unsigned int i, j, k;
unsigned char ds1, a;
void init_uart();
void init_lcd();
unsigned char uart_rx();
//void init_lcd1();
//void init_lcd2();
void cmd_wrt(unsigned char p);
void data_wrt(unsigned char q);
void enable();
void delay(unsigned int t);

void main()
{
ADCON1=0x06;
TRISA=0x00;
PORTA=0xff;
TRISA=0xfd;
TRISB=0x00;
TRISC=0xc0;
PORTB=0x00;
INTCON=0xc0;
PIE1=0x01;

init_uart();
init_lcd();

while(1)
{
ds1= uart_rx();
delay(5);
data_wrt(ds1);
delay(5);
}
}

void init_uart()
{
TXSTA=0x24;
SPBRG=25;
RCSTA=0x90;
}

unsigned char uart_rx()
{
while(RCIF==0);
a=RCREG;
RCIF=0;
return(a);
}

/*void init_lcd1()
{
for(k=0;k<=16;k++);
{
cmd_wrt(0x80);
delay(5);
init_lcd();
}
init_lcd2();
}

void init_lcd2()
{
for(k=0;k<=16;k++)
{
cmd_wrt(0xc0);
delay(5);
init_lcd();
}
}*/

void init_lcd()
{
cmd_wrt(0x03);
delay(5);
cmd_wrt(0x03);
delay(5);
cmd_wrt(0x03);
delay(5);
cmd_wrt(0x02);
delay(5);
cmd_wrt(0x28);
delay(5);
cmd_wrt(0x10);
delay(5);
cmd_wrt(0x0E);
delay(5);
cmd_wrt(0x06);
delay(5);
cmd_wrt(0x01);
delay(5);
backlight=0;
delay(5);
}

void cmd_wrt(unsigned char p)
{
rs=0;
rw=0;
PORTB=((PORTB&0x0f)|(p&0xf0));
enable();
PORTB=((PORTB&0x0f)|((p<<4)&0xf0));
enable();
}

void data_wrt(unsigned char q)
{
rs=1;
rw=0;
PORTB=((PORTB&0x0f)|(q&0xf0));
enable();
PORTB=((PORTB&0x0f)|((q<<4)&0xf0));
enable();
}

void enable()
{
en=1;
delay(1);
en=0;
}

void delay(unsigned int t)
{
int i, j;
for(i=0;i<=t; i++)
{
for(j=0; j<=120; j++);
}
}

