#include<pic.h>
void init_uart();
void uart_tx(unsigned char ch1);
unsigned char a;
void main()
{
TRISB=0x00;
TRISC=0xc0;     // C0 stands for transmit and recieve
init_uart();
uart_tx('J');
uart_tx('E');
uart_tx('S');
uart_tx('U');
uart_tx('S');
while(1);
}

void init_uart()
{
TXSTA=0x24;
SPBRG=25;
RCSTA=0x90;
}

void uart_tx(unsigned char ch1)
{
while(TXIF==0);
TXREG=ch1;
TXIF=0;
}
