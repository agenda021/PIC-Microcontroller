#include<pic.h>
void init_uart();
void uart_tx(unsigned char ch1);
void uart_delay(unsigned int t);
void message();
void uart_display();
void incr();
unsigned char ds1, ds2, ds3, ds4;
unsigned char array1[12]={"INC COUNTER"};
unsigned char look_up[]={"0123456789"};
void main()
{
TRISB=0x00;
TRISC=0xC0;
ds1, ds2, ds3, ds4=0;
init_uart();
message();
while(1)
{
uart_display();
uart_delay(100);
incr();
}
}

void message()
{
unsigned int i;
for(i=0;i<=12;i++)
{
uart_tx(array1[i]);
uart_delay(100);
}
}

void init_uart()
{
TXSTA=0x24;
SPBRG=25;
RCSTA=0x90;
}

void uart_tx(unsigned char ch1)
{
while(TXIF==0);
TXREG=ch1;
TXIF=0;
}

void incr()
{
ds1++;
if(ds1==9+1)
{
ds1=0;
ds2++;
if(ds2==9+1)
{
ds2=0;
ds3++;
if(ds3==9+1)
{
ds3=0;
ds4++;
if(ds4==9+1)
ds4=0;
}
}
}
}

void uart_display()
{
uart_tx(look_up[ds4]);
uart_delay(100);
uart_tx(look_up[ds3]);
uart_delay(100);
uart_tx(look_up[ds2]);
uart_delay(100);
uart_tx(look_up[ds1]);
uart_delay(100);
}

void uart_delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
for(j=0;j<200;j++);
}



