#include<pic.h>
#define sl1 RA1
#define sl2 RC0
#define sl3 RC1
#define sl4 RC2

#define krl1 RA2
#define krl2 RA3
#define krl3 RA4
#define krl4 RA5

unsigned char ds1, ds2, ds3, ds4;
unsigned char msg1[]={"PLEASE PRESS ANY KEY"};
unsigned char look_up[]={"0123456789ABCDEF"};
unsigned char key_ready, key_code, scan_no, temp, nkp;
unsigned int dcount, krcount;

void init_timer();
void init_keypad();
void init_uart();

void scanner();
void key_release();
void key_routine();
void out_debounce();
void uart_display();
void uart_tx(unsigned char ch1);
void message();

interrupt void isr_t1(void)
{
TMR1IF=0;
init_timer();
scanner();
}

void main()
{
ADCON1=0x06;
TRISA=0x00;
PORTA=0xff;
TRISA=0xfd;
TRISB=0x00;
TRISC=0xc0;
PORTB=0x00;
INTCON=0xc0;
PIE1=0x01;

ds1=ds2=ds3=ds4=0;
init_timer();
init_keypad();
init_uart();
message();
ds1=ds2=ds3=ds4=0;
while(1)
{
while(!key_ready==0);
key_release();
uart_display();
}
}

void init_keypad()
{
krl1=krl2=krl3=krl4=1;
scan_no=0;
key_code=0;
dcount=33;
krcount=32;
key_ready=nkp=0;
}

void init_timer()
{
TMR1H=0xfc;
TMR1L=0x18;
TMR1ON=1;
}

void key_release()
{
while(!nkp);
key_ready=0;
nkp=0;
}

void scanner()
{
switch(scan_no)
{
case 0:
sl1=0;
sl2=sl3=sl4=1;

PORTB=look_up[ds1];

temp=PORTA;
temp=temp&0x04;
temp=temp>>2;
key_routine();
scan_no++;
break;

case 1:
temp=PORTA;
temp=temp&0x08;
temp=temp>>3;
key_routine();
scan_no++;
break;

case 2:
temp=PORTA;
temp=temp&0x10;
temp=temp>>4;
key_routine();
scan_no++;
break;

case 3:
temp=PORTA;
temp=temp&0x20;
temp=temp>>5;
key_routine();
scan_no++;
break;

case 4:
sl2=0;
sl1=sl3=sl4=1;

temp=PORTA;
temp=temp&0x04;
temp=temp>>2;
key_routine();
scan_no++;
break;

case 5:
temp=PORTA;
temp=temp&0x08;
temp=temp>>3;
key_routine();
scan_no++;
break;

case 6:
temp=PORTA;
temp=temp&0x10;
temp=temp>>4;
key_routine();
scan_no++;
break;

case 7:
temp=PORTA;
temp=temp&0x20;
temp=temp>>5;
key_routine();
scan_no++;
break;

case 8:
sl3=0;
sl1=sl2=sl4=1;

temp=PORTA;
temp=temp&0x04;
temp=temp>>2;
key_routine();
scan_no++;
break;

case 9:
temp=PORTA;
temp=temp&0x08;
temp=temp>>3;
key_routine();
scan_no++;
break;

case 10:
temp=PORTA;
temp=temp&0x10;
temp=temp>>4;
key_routine();
scan_no++;
break;

case 11:
temp=PORTA;
temp=temp&0x20;
temp=temp>>5;
key_routine();
scan_no++;
break;

case 12:
sl4=0;
sl1=sl2=sl3=1;

temp=PORTA;
temp=temp&0x04;
temp=temp>>2;
key_routine();
scan_no++;
break;

case 13:
temp=PORTA;
temp=temp&0x08;
temp=temp>>3;
key_routine();
scan_no++;
break;

case 14:
temp=PORTA;
temp=temp&0x10;
temp=temp>>4;
key_routine();
scan_no++;
break;

case 15:
temp=PORTA;
temp=temp&0x20;
temp=temp>>5;
key_routine();
scan_no++;
break;
default:scan_no=0;
break;
}
}

void key_routine()
{
if(key_ready)
out_debounce();
else if(!key_ready)
{
if(dcount==33)
{
if(temp)
goto out_k;
else
{
dcount--;
key_code=scan_no;
goto out_k;
}
}
if(dcount!=33)
{
dcount--;
if(dcount!=0)
goto out_k;
else if(dcount==0)
{
if(!temp)
{
dcount=33;
goto out_k;
}
else
{
key_ready=1;
dcount=33;
goto out_k;
}
}
}
}
out_k:{};
}

void out_debounce()
{
if(!temp)
{
krcount=32;
goto out_k;
}
else 
{
krcount--;
if(krcount==0)
{
if(temp)
{
nkp=1;
krcount=32;
goto out_k;
}
}
else
goto out_k;
}
out_k:{};
}

void message()
{
unsigned int i;
for(i=0;i<=20;i++)
{
uart_tx(msg1[i]);
}
}

void init_uart()
{
TXSTA=0x24;
SPBRG=25;
RCSTA=0x90;
}

void uart_tx(unsigned char ch1)
{
while(TXIF==0);
TXREG=ch1;
TXIF=0;
}

void uart_display()
{
uart_tx(look_up[key_code]);
}









 