#include<pic.h>

#define sl1 RA1 
#define sl2 RC0
#define sl3 RC1
#define sl4 RC2

#define krl1 RA2
#define krl2 RA3
#define krl3 RA4
#define krl4 RA5

void init_keypad();
void init_timer();
void scanner();
void key_process();
void out_debounce();
void inc();
void key_release();
void key_routine();
void delay();
void init_delay();
unsigned char ds1, ds2, ds3, ds4;
unsigned char ascii_tab[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
unsigned char look_up[]={0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xee, 0x3e, 0x9c, 0x7a,0x9e, 0x8e};
unsigned char key_ready, key_code, scan_no, temp, nkp, delay_reg;
unsigned int krcount, dcount, start_count, over_bit;

interrupt void isr_t1(void)
{
	TMR1IF=0;
	delay();
	init_timer();
	scanner();
	if(over_bit==1)3:50 PM 19-Sep-17
	{
		inc();
		over_bit=0;
	}	
}


void main()
{
    ADCON1 = 0x06;
	TRISA=0x00;
	PORTA = 0xff;
	TRISA = 0b11111101;
	TRISB=0x00;
	TRISC=0x00;
	PORTB=0x00;
    INTCON=0xc0;
	PIE1=0x01;

ds1=ds2=ds3=ds4=0;
 init_timer();
 init_keypad();
init_delay();
while(1)
{
while(!key_ready);
key_release();
key_process();
}
}
void init_keypad()
{
krl1=krl2=krl3=krl4=1;
scan_no=0;
key_code=0;
dcount=33;
krcount=32;
key_ready=nkp=0;
}

void init_timer()
{
TMR1H=0xfd;
TMR1L=0x18;
TMR1ON=1;
}

void key_release()
{
while(!nkp);
key_ready=0;
nkp=0;
}

void key_process()
{

if(ascii_tab[key_code]=='A')
{
start_count=1;
goto out_pr;
}
else
{
if(ascii_tab[key_code]=='B')
{
start_count=0;
goto out_pr;
}
else
{
if(ascii_tab[key_code]=='C')
{
start_count=0;
ds1=ds2=ds3=ds4=0;
goto out_pr;
}
}
}
out_pr:{};
}

void init_delay()
{
delay_reg=0xff;
over_bit=1;
}

void delay()
{
if(over_bit==0)
{
while(delay_reg)
{
delay_reg--;
goto out_d;
}
delay_reg=0xff;
over_bit=1;
}
out_d:{};
}

void inc()
{
if(start_count==1)
{
ds1++;
if(ds1==9+1)
{
ds1=0;
ds2++;
if(ds2==9+1)
{
ds2=0;
ds3++;
if(ds3==9+1)
{
ds3=0;
ds4++;
if(ds4==9+1)
ds4=0;
}
}
}
}
}

void scanner()
{
switch(scan_no)
{
case 0:  
sl1=0;
sl2=sl3=sl4=1;
PORTB=look_up[ds1];

temp=PORTA;
temp=temp&0x04;
temp=temp>>2;
key_routine();
scan_no++;
break;

case 1:
temp=PORTA;
temp=temp&0x08;
temp=temp>>3;
key_routine();
scan_no++;
break;

case 2:
temp=PORTA;
temp=temp&0x10;
temp=temp>>4;
key_routine();
scan_no++;
break;

case 3:
temp=PORTA;
temp=temp&0x20;
temp=temp>>5;
key_routine();
scan_no++;
break;


case 4:
sl2=0;
sl1=sl3=sl4=1;

PORTB=look_up[ds2];
temp=PORTA;
temp=temp&0x04;
temp=temp>>2;
key_routine();
scan_no++;
break;

case 5:
temp=PORTA;
temp=temp&0x08;
temp=temp>>3;
key_routine();
scan_no++;
break;

case 6:
temp=PORTA;
temp=temp&0x10;
temp=temp>>4;
key_routine();
scan_no++;
break;

case 7:
temp=PORTA;
temp=temp&0x20;
temp=temp>>5; 
key_routine();
scan_no++;
break;

case 8: 	
sl3=0;
sl1=sl2=sl4=1;

PORTB=look_up[ds3];

temp=PORTA;
temp=temp&0x04;
temp=temp>>2; 
key_routine();
scan_no++;
break;

case 9:
temp=PORTA;
temp=temp&0x08;
temp=temp>>3; 
key_routine();
scan_no++;
break;

case 10:
temp=PORTA;
temp=temp&0x10;
temp=temp>>4; 
key_routine();
scan_no++;			
break; 

case 11:
temp=PORTA;
temp=temp&0x20;
temp=temp>>5; 
key_routine();
scan_no++;
break;

case 12: 	
sl4=0;
sl1=sl2=sl3=1;

PORTB=look_up[ds4];	
temp=PORTA;
temp=temp&0x04;
temp=temp>>2;
key_routine();		
scan_no++;
break;

case 13:
temp=PORTA;
temp=temp&0x08;
temp=temp>>3; 
key_routine();
scan_no++;
break;

case 14:
temp=PORTA;
temp=temp&0x10;
temp=temp>>4; 
key_routine();
scan_no++;
break;

case 15:
PORTB=0x00;
temp=PORTA;
temp=temp&0x20;
temp=temp>>5; 
key_routine();
scan_no++;
break;

default: scan_no=0;
break;
	
}
}

void key_routine()
{
if(key_ready)
out_debounce();
else if(!key_ready)
{
if(dcount==33)
{
if(temp)
goto out_k;
else
{
dcount--;
key_code=scan_no;
goto out_k;
}
}
if(dcount!=33)
{
dcount--;
if(dcount!=0)
goto out_k;
else if(dcount==0)
{
if(!temp)
{
dcount=33;
goto out_k;
}
else
{
key_ready=1;
dcount=33;
goto out_k;
}
}
}
}
out_k:{};
}

void out_debounce()
{
if(!temp)
{
krcount=32;
goto out_k;
}
else
{
krcount--;
if(krcount==0)
{
if(temp)
{
nkp=1;
krcount=32;
goto out_k;
}
}
else
goto out_k;
}
out_k:{};
}

