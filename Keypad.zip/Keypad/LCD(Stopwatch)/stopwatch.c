//stopwatch
#include<pic.h>

#define sl1 RA1
#define sl2 RC0
#define sl3 RC1
#define sl4 RC2

#define krl1 RA2
#define krl2 RA3
#define krl3 RA4
#define krl4 RA5

#define backlight RB0
#define rs RB1
#define rw RB2
#define en RB3

void message();
void init_lcd();
void delay_1ms(unsigned int t);
void lcd_cw(unsigned char);
void lcd_dw(unsigned char);
void enable();
void lcd_display();

unsigned char msg1[]={"STOPWATCH"};
unsigned char look_up[]={"0123456789ABCDEF"};
unsigned char ds1,ds2,ds3,ds4;
unsigned char key_ready,key_code,scan_no,temp,nkp,start_count;
unsigned int dcount,krcount,delay_reg,ovr_bit;

void init_keypad();
void init_timer();
void scanner();
void delay1();
void init_delay_1sec();
void count_process();
void key_process();
void key_routine();
void key_release();
void out_debounce();

interrupt void isr_t1(void)
{
	TMR1IF=0;=
	delay1();
	init_timer();
	scanner();	
	if(ovr_bit==1)
	{
		count_process();
		ovr_bit=0;
	}	
}
void main()
{
	ADCON1 = 0x06;
	TRISA=0x00;
	PORTA = 0xff;
	TRISA = 0b11111101;
	TRISB=0x00;
	TRISC=0x00;
	PORTB=0x00;
      INTCON=0xc0;
	PIE1=0x01;//enable timer overflow enable bit
	init_timer();
	init_keypad();
	init_delay_1sec();
	init_lcd();
	message();
	ds1=ds2=ds3=ds4=0;

	while(1)
	{
		while(key_ready==0)
		{
			lcd_display();
		}
		key_process();
		key_release();	
	}		
}
void message()
{
	unsigned int i;
	lcd_cw(0x80);
	delay_1ms(5);
	for (i=0;i<9;i++)
		lcd_dw(msg1[i]);
}
void lcd_display()
{
	lcd_cw(0xc5);
	delay_1ms(5);
	lcd_dw(look_up[ds4]);
	delay_1ms(5);
	lcd_dw(look_up[ds3]);
	delay_1ms(5);
	lcd_dw(':');
	lcd_dw(look_up[ds2]);
	delay_1ms(5);
	lcd_dw(look_up[ds1]);
	delay_1ms(5);
}
//===========================================
void init_keypad()
{
	krl1=krl2=krl3=krl4=1;
	scan_no=0;
	key_code=0;
	dcount=33;
	krcount=32;
	key_ready=nkp=0;
}
void init_timer()
{
	TMR1H=0x0fc;//load high reg
	TMR1L=0x18;//load low reg
	TMR1ON=1;// timer run flag on
	
}
void key_release()
{
	while(nkp==0);
		key_ready=0;
		nkp=0;

}
void key_process()
{
	//ds1=ascii_tab[key_code];
	if(look_up[key_code]=='A')
	{
		start_count=1;
		goto out_pr;
	}
	else
	{
		 if(look_up[key_code]=='B')
		{
				start_count=0;
				goto out_pr;
		}
		else
		{
			 if(look_up[key_code]=='C')
			{
				start_count=0;
				ds1=ds2=ds3=ds4=0;
				goto out_pr;
			}
		}
	}
out_pr:{};
}
void init_delay_1sec()
{
	delay_reg=0xff;
	ovr_bit=1;
}

void delay1()
{
	if(ovr_bit==0)
	{
		while(delay_reg)
		{
			delay_reg--;
			goto out_d;
		}
		delay_reg=0xff;
		ovr_bit=1;
	}
	out_d:{};
}
void count_process()
{
	if(start_count==1)
	{
		ds1++;
		if(ds1==9+1)
		{
			ds1=0;
			ds2++;
			if(ds2==9+1)
			{
				ds2=0;
				ds3++;
				if(ds3==9+1)
				{
					ds3=0;
					ds4++;
					if(ds4==9+1)
						ds4=0;
				}
			}
		}
	}
}

void scanner()
{
	switch(scan_no)
	{
		case 0: 	
			sl1=0;
			sl2=sl3=sl4=1;

			//to obtain cy
			temp=PORTA;
			temp=temp&0x04;//0b00000100; masking RA2 bit
			temp=temp>>2; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 1:
			temp=PORTA;
			temp=temp&0x08;//0b00001000; masking RA3 bit
			temp=temp>>3; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 2:
			temp=PORTA;
			temp=temp&0x10;//0b00010000; masking RA4 bit
			temp=temp>>4; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 3:
			temp=PORTA;
			temp=temp&0x20;//0b00100000; masking RA4 bit
			temp=temp>>5; //shift right to 2 places
			key_routine();
			scan_no++;
			break;

		case 4: 	
			sl2=0;
			sl1=sl3=sl4=1;

			//to obtain cy
			temp=PORTA;
			temp=temp&0x04;//0b00000100; masking RA2 bit
			temp=temp>>2; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 5:
			temp=PORTA;
			temp=temp&0x08;//0b00001000; masking RA3 bit
			temp=temp>>3; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 6:
			temp=PORTA;
			temp=temp&0x10;//0b00010000; masking RA4 bit
			temp=temp>>4; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 7:
			temp=PORTA;
			temp=temp&0x20;//0b00100000; masking RA4 bit
			temp=temp>>5; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 8: 	
			sl3=0;
			sl1=sl2=sl4=1;

			//to obtain cy
			temp=PORTA;
			temp=temp&0x04;//0b00000100; masking RA2 bit
			temp=temp>>2; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 9:
			temp=PORTA;
			temp=temp&0x08;//0b00001000; masking RA3 bit
			temp=temp>>3; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 10:
			temp=PORTA;
			temp=temp&0x10;//0b00010000; masking RA4 bit
			temp=temp>>4; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 11:
			temp=PORTA;
			temp=temp&0x20;//0b00100000; masking RA4 bit
			temp=temp>>5; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 12: 	
			sl4=0;
			sl1=sl2=sl3=1;

			//to obtain cy
			temp=PORTA;
			temp=temp&0x04;//0b00000100; masking RA2 bit
			temp=temp>>2; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 13:
			temp=PORTA;
			temp=temp&0x08;//0b00001000; masking RA3 bit
			temp=temp>>3; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 14:
			temp=PORTA;
			temp=temp&0x10;//0b00010000; masking RA4 bit
			temp=temp>>4; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		case 15:
		//	PORTB=0x00;
			temp=PORTA;
			temp=temp&0x20;//0b00100000; masking RA4 bit
			temp=temp>>5; //shift right to 2 places
			key_routine();
			scan_no++;
			break;
		default: scan_no=0;
				break;
			
	}
}
void key_routine()
{
	if(key_ready)
		out_debounce();
	else if(!key_ready)
	{
		if(dcount==33)
		{
			if(temp)
				goto out_k;
			else
			{
				dcount--;
				key_code=scan_no;
				goto out_k;
			}
		  }
		if(dcount!=33)
		{
			dcount--;
			if(dcount!=0)
				goto out_k;
			else if(dcount==0)
			{
				if(!temp)
				{
					dcount=33;
					goto out_k;
				}
				else
				{
					key_ready=1;
					dcount=33;
					goto out_k;
				}
			}
		}
	}
out_k: {};
}
void out_debounce()
{
	if(!temp)
	{
		krcount=32;
		goto out_k;
	}
	else
	{
		krcount--;
		if(krcount==0)
		{
			if(temp)
			{
				nkp=1;
				krcount=32;
				goto out_k;
			}
		}
		else
			goto out_k;
	}
out_k:{};
}


///===========================================
void init_lcd()
{
	delay_1ms(15);
	lcd_cw(0x03);
	delay_1ms(5);
	lcd_cw(0x03);
	delay_1ms(5);
	lcd_cw(0x03);
	delay_1ms(5);

	lcd_cw(0x02);  //4 bit enable
	delay_1ms(5);
	
	lcd_cw(0x2C);  //2 line display
	delay_1ms(5);
	lcd_cw(0x10); //cursor move
	delay_1ms(5);
	lcd_cw(0x0c); //enable cursor/display
	delay_1ms(5);
	lcd_cw(0x06); //set cursor move direction
	delay_1ms(5);
	lcd_cw(0x01);//clear display
	delay_1ms(5);
	backlight=0;
}

void lcd_cw(unsigned char p)
{
	rs=0;
	rw=0;
	PORTB=((PORTB & 0x0f) | (p & 0xf0));
	enable();
	PORTB=((PORTB & 0x0f) | ((p<<4) & 0xf0));
	enable();
}

void lcd_dw(unsigned char q)
{
	rs=1;
	rw=0;
	PORTB=((PORTB & 0x0f) | (q & 0xf0));
	enable();
	PORTB=((PORTB & 0x0f) | ((q<<4) & 0xf0));
	enable();
}

void enable()
{
	en=1;
	delay_1ms(5);
	en=0;
	delay_1ms(2);
}

void delay_1ms(unsigned int t)
{
	unsigned int i,j;
	for (i=0;i<t;i++)
		for(j=0;j<120;j++);
}