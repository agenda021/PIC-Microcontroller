				//POLLING METHOD//

#include<pic.h>
#define sl1  RA1  //output port1 transistor sevensegment
#define sl2  RC0  //output port2 transistor sevensegment
#define sl3  RC1  //output port3 transistor sevensegment
#define sl4  RC2    //output port4 transistor sevensegment
#define krl1 RA2  //from keypad input1
#define krl2 RA3   //from keypad input2
#define krl3 RA4  //from keypad input3
#define krl4 RA5  //from keypad input4
//void delay(unsigned int t);
unsigned char look_up[]={0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6, 0xee, 0x3e, 0x9c, 0x7a, 0x9e, 0x8e};
unsigned char ds1;
void main()
{
ADCON1=0x06;
TRISB=0x00;
TRISA=0x3C;           //setting as input ports 0011 1100
TRISC=0x00;

while(1)
{

//0-3//
PORTB=0x00;
PORTA=0x00;
sl1=0;
sl2=sl3=sl4=1;
PORTB=look_up[ds1];
if(krl1==0)
ds1=0;
else if(krl2==0)
ds1=1;
else if(krl3==0)
ds1=2;
else if(krl4==0)
ds1=3;

//4-7//
PORTB=0x00;
sl2=0;
sl1=sl3=sl4=1;
if(krl1==0)
ds1=4;
else if(krl2==0)
ds1=5;
else if(krl3==0)
ds1=6;
else if(krl4==0)
ds1=7;

//8-B//
PORTB=0x00;
sl3=0;
sl1=sl2=sl4=1;
if(krl1==0)
ds1=8;
else if(krl2==0)
ds1=9;
else if(krl3==0)
ds1=10;
else if(krl4==0)
ds1=11;

//C-F//
PORTB=0x00;
sl4=0;
sl1=sl2=sl3=1;
if(krl1==0)
ds1=12;
else if(krl2==0)
ds1=13;
else if(krl3==0)
ds1=14;
else if(krl4==0)
ds1=15;

}
}