#include<pic.h>
#define backlight RB0
#define rs RB1
#define rw RB2
#define en RB3
void init_lcd();
void delay(unsigned int t);
void lcd_cw(unsigned char);
void lcd_dw(unsigned char);
void enable();
void main()
{
TRISB=0x00;
PORTB=0x00;
init_lcd(0x80);
lcd_dw('J');
delay(50);
lcd_dw('E');
delay(50);
lcd_dw('S');
delay(50);
lcd_dw('U');
delay(50);
lcd_dw('S');
delay(50);

while(1)
{
lcd_cw(0x1C);
delay(50);
}
}

void init_lcd()
{
delay(15);
lcd_cw(0x03);
delay(5);
lcd_cw(0x03);
delay(5);
lcd_cw(0x03);
delay(5);
lcd_cw(0x02);
delay(5);
lcd_cw(0x28);  //set interface length
delay(5);
lcd_cw(0x10);  // move cursor shift display
delay(5);
lcd_cw(0x0e);  // enable display cursor
delay(5);
lcd_cw(0x06);  //cursor move direction
delay(5);
lcd_cw(0x01);  //clear display
delay(5);
backlight=0;
}

void lcd_cw(unsigned char p)
{
rs=0;
rw=0;
PORTB=((PORTB&0x0f)|(p&0xf0));
enable();
PORTB=((PORTB&0x0f)|((p<<4)&0xf0));
enable();
}

void lcd_dw(unsigned char q)
{
rs=1;
rw=0;
PORTB=((PORTB&0x0f)|(q&0xf0));
enable();
PORTB=((PORTB&0x0f)|((q<<4)&0xf0));
enable();
}

void enable()
{
en=1;
delay(2);
en=0;
delay(2);
}

void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<=t;i++)
for(j=0;j<=120;j++);
}
