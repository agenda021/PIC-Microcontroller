#include<pic.h>
#define backlight RB0
#define rs RB1
#define rw RB2
#define en RB3
void init_lcd();
void delay(unsigned int a);
void lcd_cw(unsigned char);
void lcd_dw(unsigned char);
void enable();
void main()
{
TRISB=0x00;
PORTB=0x00;
init_lcd();
lcd_cw(0x86);
lcd_dw('J');
lcd_dw('E');
lcd_dw('S');
lcd_dw('U');
lcd_dw('S');
while(1);
}

void init_lcd()
{
delay(15);
lcd_cw(0x03);
delay(5);
lcd_cw(0x03);
delay(5);
lcd_cw(0x03);
delay(5);

lcd_cw(0x02);
delay(5);
lcd_cw(0x10);
delay(5);
lcd_cw(0x10);
delay(5);
lcd_cw(0x0C);
delay(5);
lcd_cw(0x06);
delay(5);
lcd_cw(0x01);
delay(5);
backlight=0;
}

void lcd_cw(unsigned char p)
{
rs=0;
rw=0;
PORTB=((PORTB&0x0f)|(p&0xf0));
enable();
PORTB=((PORTB&0x0f)|((p<<4)&0xf0));
enable();
}

void lcd_dw(unsigned char q)
{
rs=1;
rw=0;
PORTB=((PORTB&0x0f)|(q&0xf0));
enable();
PORTB=((PORTB&0x0f)|((q<<4)&0xf0));
enable();
}

void enable()
{
en=1;
delay(2);
en=0;
delay(2);
}

void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<=t;i++)
for(j=0;j<=120;j++);
}