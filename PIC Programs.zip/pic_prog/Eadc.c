#include<pic.h>
void delay(unsigned int k);
 unsigned int adc(void);
void main(void)
{

unsigned int z,timer;
TRISA=0X1F;
TRISB=0X00;
while(1)
{
//timer=adc();
//timer=timer/0xf0;
//do
//{
z=adc();
delay(z);
PORTB=0X80;
z=adc();
delay(z);
PORTB=0x40;
z=adc();
delay(z);

PORTB=0X20;
z=adc();
delay(z);
PORTB=0x10;
z=adc();
delay(z);

PORTB=0X08;
z=adc();
delay(z);
PORTB=0x04;
//timer=timer-9;
//}while(timer!=0);
//PORTB=0XFF;
}
}


 unsigned int adc(void)
{
 unsigned int a,b,c;

ADCON1=0X40;
ADCON0=0X01;
while(1)
{
//PORTB=0XFF;
delay(50);
a=ADCON0;
a=a|0x04;
ADCON0=a;  //set GO/DONE BIT

do
{
c=PIR1;
}while(c!=0X40);
b=ADRESH;

PIR1=0X00;
return(b);
}
}
void delay(unsigned int k)
{
 int i,j;
for(i=0;i<=k;i++)
{
  for(j=0;j<50;j++){};
}
}

//tested ok