#include <pic.h>
#define sl1 RC2
#define sl2 RC1
#define sl3 RC0
#define sl4 RA1

void delay(unsigned int t);
void display();

void main()
{
PORTB=0x00;
TRISB=0x00;
TRISA=0x00;
TRISC=0x00;
display();
}

void display()
{
while(1)
{
sl1=0;
sl2=1;
sl3=1;
sl4=1;
PORTB=0x60;
delay(3);
sl1=1;
sl2=0;
sl3=1;
sl4=1;
PORTB=0xF6;
delay(3);
sl1=1;
sl2=1;
sl3=0;
sl4=1;
PORTB=0xF6;
delay(3);
sl1=1;
sl2=1;
sl3=1;
sl4=0;
PORTB=0xBE;
delay(3);
}
}

void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<=t;i++)
{
for(j=0;j<=120;j++);
}
}