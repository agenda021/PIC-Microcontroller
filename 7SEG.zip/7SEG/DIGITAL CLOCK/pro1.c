#include<pic.h>
#define sl1 RA1
#define sl4 RC2
#define sl3 RC1
#define sl2 RC0
#define yes RB0

void delay(unsigned int t);
void inc_d();
void display();
unsigned char k, ds1, ds2, ds3, ds4;
unsigned int luk[10]= {0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xe6};
{
TRISC=0x00;
TRISA=0x00;
TRISB=0x00;
PORTB=0x00;
while(1)
{
for(k=0;k<=10;k++)
{
display();
}
inc_d();
}
}

void display()
{
sl1=0;
sl2=1;
sl3=1;
sl4=1;
PORTB=luk[ds1];
delay(5);
sl1=1;
sl2=0;
sl3=1;
sl4=1;
PORTB=luk[ds2];
delay(5);
sl1=1;
sl2=1;
sl3=0;
sl4=1;
PORTB=luk[ds3];
yes=1;
delay(5);
sl1=1;
sl2=1;
sl3=1;
sl4=0;

PORTB=luk[ds4];

delay(5);
}

void inc_d()
{
ds1++;
if(ds1==9+1)
{
ds1=0;
ds2++;
}
if(ds2==5+1)
{
ds2=0;
ds3++;
}
if(ds4<=0+1)
{
   if(ds3==9+1)
   {
   ds3=0;
   ds4++;
	}
}
else if(ds4==1+1)
{
if(ds3==3+1)
{
ds3=0;
ds2=0;
ds1=0;
ds4=0;
}
}
}

void delay(unsigned int t)
{
unsigned int i,j;
for(i=0; i<=t; i++)
{
for(j=0; j<=10; j++) ;
}
}












































































































