/*#include<pic.h>
#define sl4 RC2
#define sl3 RC1
#define sl2 RC0
#define sl1 RA1

void delay(unsigned int t);
void display();
//void inc();
void dec();
void display(2);
unsigned char luk1[10]={0xf6, 0xfe, 0xe0, 0xbe, 0xb6, 0x66, 0xf2, 0xda, 0x60, 0xfc};
unsigned char luk[10]={0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xe6};
unsigned char ds1, ds2, ds3, ds4;
unsigned int k;

void main()
{
TRISB=0x00;
TRISA=0x00;
TRISC=0x00;
PORTB=0x00;
ds1=ds2=ds3=ds4=9;
while(1)
{
for(k=0;k<=10;k++)
{
display();
}
//inc();
dec();
}
}

void display()
{
sl1=0;
sl2=1;
sl3=1;
sl4=1;
PORTB=luk[ds1];
delay(2);
sl2=0;
sl1=1;
sl3=1;
sl4=1;
PORTB=luk[ds2];
delay(2);
sl3=0;
sl1=1;
sl2=1;
sl4=1;
PORTB=luk[ds3];
delay(2);
sl4=0;
sl2=1;
sl3=1;
sl1=1;
PORTB=luk[ds4];
delay(2);
}

void inc()
{
ds1++; 
if (ds1==9+1)
{
ds1=0;
ds2++;
if(ds2==9+1)
{
ds2=0;
ds3++;
if (ds3==9+1)
{
ds3=0;
ds4++;
if (ds4==9+1)
{
if(ds4==9)
{
if(ds3==9)
{
if(ds2==9)
{
if(ds1==9)
{
dec();
}
}
}
}
}
}
}
}
}

void dec()
{
ds1--; 
if (ds1==0-1)
{
ds1=9;
ds2--;
if(ds2==0-1)
{
ds2=9;
ds3--;
if(ds3==0-1)
{
ds3=9;
ds4--;
if(ds4==0-1)
{
ds1=0;
ds2=0;
ds3=0;
ds4=0;
}
}
}
}
}

void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<=t;i++)
{
for(j=0;j<=1;j++);
}
}
*/


#include<pic.h>
#define sl4 RC2
#define sl3 RC1
#define sl2 RC0
#define sl1 RA1
void	delay();
void	display();
void	inc_d();
void	dec_d();

unsigned char flag1;
unsigned char disp[]={0xfc,0x60,0xda,0xf2,0x66,0xb6,0xbe,0xe0,0xfe,0xe6};
unsigned char ds1,ds2,ds3,ds4;
unsigned int i,k,count;
void main()
{
    TRISB=0x00;
    TRISA=0x00;
    TRISC=0x00;
	ds1,ds2,ds3,ds4=0;
	while(1)
	{
	if(flag1==0)
	{
//	for(count=0;count<=28;count++)
	{
	display();
	}
  	 inc_d();
	}
	if(flag1==1)
	{
//	  for(count=0;count<=28;count++)
	{
	display();
	}
	dec_d();
	}
	}
}


void	display()
{
	
	sl1=0;
	sl2=1;
	sl3=1;
	sl4=1;
	PORTB =disp[ds1];
	delay();
	sl1=1;
	sl2=0;
	sl3=1;
	sl4=1;
	PORTB =disp[ds2];
	delay();
	sl1=1;
	sl2=1;
	sl3=0;
	sl4=1;
	PORTB =disp[ds3];
	delay();
	sl1=1;
	sl2=1;
	sl3=1;
	sl4=0;
	PORTB =disp[ds4];
	delay();
}
	
   
	void delay()
  {
   for(i=0;i<=425;i++)
  {
  }
  }

  void inc_d()
{
  	ds1++;
	if(ds1==9+1)
	{
		ds1=0;
		ds2++;
	if(ds2==9+1)
	{
		ds2=0;
		ds3++;
	if(ds3==9+1)
	{
		ds3=0;
		ds4++;
	if(ds4==9+1)
	{
		ds4=9;
		ds3=9;
		ds2=9;
		ds1=9;
		flag1=1;
			  }
		  }
	  }
  }
}


void dec_d()
{
	ds1--;
	if(ds1==0)
	{
	ds1=9;
	ds2--;
	if(ds2==0)
	{
		ds2=9;
		ds3--;
	if(ds3==0)
	{
		ds3=9;
		ds4--;
	if(ds4==0)
	{
		ds4=0;
		ds3=0;
		ds2=0;
		ds1=0;
	   flag1=0;
			  }
		  }
	  }
    }


}	
	 