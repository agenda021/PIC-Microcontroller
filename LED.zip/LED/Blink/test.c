#include <pic.h>
void delay(unsigned int t);

void main()
{
PORTB=0x00;
TRISB=0x00;
while(1)
{
PORTB=0x01;
delay(500);
PORTB=0x00;
delay(500);
}
}
void delay(unsigned int t)
{
unsigned int i, j;
for(i=0;i<=t;i++)
{
for(j=0;j<=120;j++);
}
}