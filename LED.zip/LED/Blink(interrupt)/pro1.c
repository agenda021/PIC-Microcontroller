#include<pic.h>
#define led1 RB1
#define led2 RB3
#define led3 RB5

void init_timer1();

void main()
{
TRISB=0x00;
PORTB=0x00;
init_timer1();
INTCON=0xC0;
while(1);
}

void init_timer1()
{
T1CON=0x04;		//T1CON:	 �   	   �   T1CKPS1   T1CKPS0   T1OSCEN   /T1SYNC   TMR1CS   TMR1ON	
TMR1H=0x45;
TMR1L=0x60;
TMR1ON=1;
PIE1=0x01;		//PIE1:		PSPIE(2)  ADIE  RCIE     TXIE       SSPIE    CCP1IE   TMR2IE   TMR1IE
}

interrupt void isr_t1(void)
{
//unsigned char temp;
led1=~led1;
led2=~led2;
led3=~led3;
TMR1IF=0;
}
