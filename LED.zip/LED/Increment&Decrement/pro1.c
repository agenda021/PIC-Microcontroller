
#include<pic.h>
void delay(unsigned int t);
//void increment();
//void decrement();
//unsigned int k;
void main()
{
TRISB=0x00;
while(1)
{
PORTB=0x00;
while(PORTB<0xff)
{
delay(100);
PORTB++;
}
while(PORTB>0x00)
{
delay(100);
PORTB--;
}
}
}

void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<=t;i++)
{
for(j=0;j<=70;j++);
}
}

