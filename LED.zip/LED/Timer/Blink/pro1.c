#include<pic.h>
void timer1();
#define led1 RB0
#define led2 RB4
#define led4 RB3
#define led3 RB7

void main()
{
TRISB=0x00;
PORTB=0x00;
while(1)
{
led1=1;
led3=1;
led2=0;
led4=0;
timer1();
timer1();
timer1();
timer1();
timer1();
timer1();
led2=1;
led4=1;
led1=0;
led3=0;
timer1();
timer1();
timer1();
timer1();
timer1();
timer1();
PORTB=0X00;
timer1();
timer1();
timer1();
timer1();
timer1();
}
}

void timer1()
{
unsigned int i;
T1CON=0x04;
for(i=0;i<=500;i++)
{
TMR1H=0xff;
TMR1L=0x01;
TMR1ON=1;
while(!TMR1IF);
TMR1IF=0;
}
}