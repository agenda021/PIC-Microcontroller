#include<pic.h>
void timer1();
void pack();

void main()
{
TRISB=0x00;
PORTB=0x00;
while(1)
{
PORTB=0x01;
pack();
PORTB=0x02;
pack();
PORTB=0x04;
pack();
PORTB=0x08;
pack();
PORTB=0x10;
pack();
PORTB=0x20;
pack();
PORTB=0x40;
pack();
PORTB=0x80;
pack();
}
}

void pack()
{
timer1();
timer1();
timer1();
timer1();
timer1();
timer1();
}

void timer1()
{
unsigned int i;
T1CON=0x04;
for(i=0;i<=1000;i++)
{
TMR1H=0xff;
TMR1L=0x05;
TMR1ON=1;
while(!TMR1IF);
TMR1IF=0;
}
}
